package com.cg.dao;

public interface QueryMapper {

	public static final String EMPLOYEE_LOGIN = "SELECT role FROM employeeMaster WHERE employeeCode=? AND password=?";
	
	public static final String FACULTY_MAINTENANCE = "INSERT INTO facultySkill VALUES(?,?,?)";
	public static final String VIEW_FACULTY_MAINTENANCE = "SELECT * FROM facultySkill";
	public static final String UPDATE_FACULTY_MAINTENANCE = "UPDATE facultySkill SET facultyName=?,skillSet=? WHERE facultyCode=?";
	public static final String DELETE_FACULTY_MAINTENANCE = "DELETE FROM facultySkill WHERE facultyCode=?";
	public static final String COURSE_MAINTENANCE = "INSERT INTO courseMaster VALUES(courseId_sequence.NEXTVAL,?,?)";
	
	
	public static final String TRAINING_MAINTENANCE = "INSERT INTO trainingProgram VALUES(?,?,?,?,?)";
	public static final String VIEW_TRAINING_PROGRAM = "SELECT * FROM trainingProgram";
	public static final String UPDATE_TRAINING_PROGRAM = "UPDATE trainingProgram SET courseCode=?,facultyCode=?,startDate=?,endDate=? WHERE trainingCode=?";
	public static final String DELETE_TRAINING_PROGRAM = "DELETE FROM trainingProgram WHERE trainingCode=?";
	public static final String PARTICIPANT_ENROLLMENT = "INSERT INTO trainingParticipantEnrollment VALUES(?,?)";
	public static final String EMPLOYEE_PARTICIPANT = "INSERT INTO employeeMaster VALUES(?,?,?,?)";
	
	
	public static final String PARTICIPANT_FEEDBACK = "INSERT INTO feedbackMaster VALUES(?,?,?,?,?,?,?,?,?)";
	public static final String VIEW_FACULTY_REPORT = "SELECT f.fbPrsComm,f.fbClrfyDbts,f.fbTm  FROM feedbackMaster f  INNER JOIN trainingProgram t ON t.trainingCode = f.trainingCode WHERE EXTRACT(MONTH FROM startDate)<=? AND EXTRACT(MONTH FROM endDate)>=? ";
	public static final String VIEW_TRAINING_REPORT = "SELECT f.fbPrsComm,f.fbClrfyDbts,f.fbTm,f.fbHndOut,f.fbHwSwNtwrk  FROM feedbackMaster f  INNER JOIN trainingProgram t ON t.trainingCode = f.trainingCode WHERE EXTRACT(MONTH FROM startDate)<=? AND EXTRACT(MONTH FROM endDate)>=? ";
	public static final String GET_TRAINING_CODE = "SELECT trainingCode from trainingParticipantEnrollment where participantCode=?";
	public static final String RETRIEVE_TRAINING = "SELECT courseCode,facultyCode,startDate,endDate FROM trainingProgram where trainingCode=?";

}
