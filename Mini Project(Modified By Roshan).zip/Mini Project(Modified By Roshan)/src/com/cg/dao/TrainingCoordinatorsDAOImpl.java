package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.EmployeeMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.bean.TrainingParticipantEnrollmentBean;
import com.cg.bean.TrainingProgramBean;
import com.cg.exception.FeedBackException;
import com.cg.util.DBConnection;



public class TrainingCoordinatorsDAOImpl implements ITrainingCoordinatorsDAO 
{

	@Override
	public boolean trainingProgramMaintenance(
			TrainingProgramBean trainingProgram) throws FeedBackException {
		
		CourseMasterBean courseMasterBean = new CourseMasterBean();
		FacultySkillBean facultySkillBean = new FacultySkillBean();
		boolean isInserted = false;
		try(Connection conn = DBConnection.getInstance().getConnection();) 
		{
			
			PreparedStatement preparedStatement=
				conn.prepareStatement(QueryMapper.TRAINING_MAINTENANCE);
		
			int records=0;
			
		
			preparedStatement.setString(1, courseMasterBean.getCourseName());
			preparedStatement.setString(2, facultySkillBean.getFacultyName());
			preparedStatement.setDate(3, (Date) trainingProgram.getStartDate());
			preparedStatement.setDate(4, (Date) trainingProgram.getEndtDate());
		
			records=preparedStatement.executeUpdate();
			isInserted = true;
			System.out.println("inside trainingProgramMaintenance dao ");
			if(records==0)
			{
				throw new FeedBackException("Inserting training maintainance details failed ");

			}
			else
			{
				return isInserted;
		
			}
		
		}
		catch(SQLException sqlEx)
		{
			throw new FeedBackException(sqlEx.getMessage());
		}
	}

	@Override
	public boolean participantEnrollment(
			TrainingParticipantEnrollmentBean participant)
			throws FeedBackException {
		
		CourseMasterBean courseMasterBean = new CourseMasterBean();
		boolean isInserted = false;

		try(Connection conn = DBConnection.getInstance().getConnection();) 
		{
			
			PreparedStatement preparedStatement=
				conn.prepareStatement(QueryMapper.PARTICIPANT_ENROLLMENT);
		
			int records=0;
			
			preparedStatement.setString(1, participant.getParticipantCode());
			preparedStatement.setString(2, courseMasterBean.getCourseName());
			
			records=preparedStatement.executeUpdate();
			isInserted = true;
			System.out.println("inside participantEnrollment dao ");
			if(records==0)
			{
				throw new FeedBackException("Inserting participantEnrollment failed ");

			}
			else
			{
				return isInserted;
		
			}
		
		}
		catch(SQLException sqlEx)
		{
			throw new FeedBackException(sqlEx.getMessage());
		}
	}

	@Override
	public boolean employeeParticipant(EmployeeMasterBean employee)
			throws FeedBackException {
		
		boolean isInserted = false;

		try(Connection conn = DBConnection.getInstance().getConnection();) 
		{
			
			PreparedStatement preparedStatement=
				conn.prepareStatement(QueryMapper.EMPLOYEE_PARTICIPANT);
		
			int records=0;
			
			preparedStatement.setString(1, employee.getEmployeeId());
			preparedStatement.setString(2, employee.getEmployeeName());
			preparedStatement.setString(3, employee.getPassword());
			preparedStatement.setString(4, employee.getRole());
			
			records=preparedStatement.executeUpdate();
			isInserted = true;
			System.out.println("inside employeeParticipant dao ");
			if(records==0)
			{
				throw new FeedBackException("Inserting employeeParticipant failed ");

			}
			else
			{
				return isInserted;
		
			}
		
		}
		catch(SQLException sqlEx)
		{
			throw new FeedBackException(sqlEx.getMessage());
		}
		
	}

	@Override
	public List<TrainingProgramBean> viewTrainingProgram()
			throws FeedBackException {
		
int pgmCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<TrainingProgramBean> trainingProgramList=new ArrayList<TrainingProgramBean>();
		try
		{
			Connection con=DBConnection.getInstance().getConnection();
			ps=con.prepareStatement(QueryMapper.VIEW_TRAINING_PROGRAM);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				TrainingProgramBean bean=new TrainingProgramBean();
				bean.setTrainingCode(resultset.getString(1));
				bean.setCourseCode(resultset.getString(2));
				bean.setFacultyCode(resultset.getString(3));
				bean.setStartDate(resultset.getDate(4));
				bean.setEndtDate(resultset.getDate(5));
				
				trainingProgramList.add(bean);
				
				pgmCount++;
			}			
			
		} catch (SQLException sqlException) {
			
			throw new FeedBackException("Problem occured in trainingProgramList view all Dao.");
		}

		if(pgmCount == 0)
			return null;
		else
			return trainingProgramList;
	}

	@Override
	public boolean updateTraining(TrainingProgramBean trainingProgram)
			throws FeedBackException {
		
		int records=0;
		boolean isUpdated=false;
		
		try(Connection connMobile = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
				connMobile.prepareStatement(QueryMapper.UPDATE_TRAINING_PROGRAM);)
		{
			
			
			preparedStatement.setString(1, trainingProgram.getFacultyCode());
			preparedStatement.setDate(2, (Date) trainingProgram.getStartDate());
			preparedStatement.setDate(3, (Date) trainingProgram.getEndtDate());
			preparedStatement.setString(4, trainingProgram.getTrainingCode());
			
			records=preparedStatement.executeUpdate();
			
			if(records>0)
				isUpdated=true;
			
		}
		catch(SQLException sqlEx)
		{
			throw new FeedBackException(sqlEx.getMessage());
		}
		
		return isUpdated;

	}

	@Override
	public boolean deleteTraining(String trainingCode) throws FeedBackException {
		
		int records=0;
		boolean isDeleted=false;
		
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
				connPurchaseDetails.prepareStatement(QueryMapper.DELETE_TRAINING_PROGRAM);)
		{
						
			preparedStatement.setString(1, trainingCode);
			
			records=preparedStatement.executeUpdate();
			
			if(records>0)
				isDeleted=true;
			
		}
		catch(SQLException sqlEx)
		{
			throw new FeedBackException(sqlEx.getMessage());
		}
		
		return isDeleted;
	}

	@Override
	public List<FeedbackMasterBean> viewTrainingProgramReport(int month)
			throws FeedBackException {
		
int pgmCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<FeedbackMasterBean> trainingProgramReportList=new ArrayList<FeedbackMasterBean>();
		try
		{
			TrainingProgramBean trainingProgram = new TrainingProgramBean();
			Connection con=DBConnection.getInstance().getConnection();
			ps=con.prepareStatement(QueryMapper.VIEW_TRAINING_REPORT);
			resultset=ps.executeQuery();
			ps.setDate(6, (Date) trainingProgram.getStartDate());
			ps.setDate(7, (Date) trainingProgram.getEndtDate());
			while(resultset.next())
			{	
				FeedbackMasterBean bean=new FeedbackMasterBean();
				bean.setPresentationCommunication(resultset.getInt(1));
				bean.setClearifyDoubts(resultset.getInt(2));
				bean.setTimeManagement(resultset.getInt(3));
				bean.setHandOuts(resultset.getInt(4));
				bean.setHwSwNtwrk(resultset.getInt(5));
				
				trainingProgramReportList.add(bean);
				
				pgmCount++;
			}			
			
		} catch (SQLException sqlException) {
			
			throw new FeedBackException("Problem occured in trainingProgramReportList view all Dao.");
		}

		if(pgmCount == 0)
			return null;
		else
			return trainingProgramReportList;
	}

	@Override
	public TrainingProgramBean retrieveTraining(String trainingCode) throws FeedBackException {
		
		TrainingProgramBean bean;
		ResultSet resultset = null;
		 bean=null;
		
		try(Connection conn = DBConnection.getInstance().getConnection();) 
		{
			
			PreparedStatement preparedStatement=
				conn.prepareStatement(QueryMapper.RETRIEVE_TRAINING);
			
			preparedStatement.setString(1,trainingCode);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new TrainingProgramBean();
				bean.setCourseCode(resultset.getString(1));
				bean.setFacultyCode(resultset.getString(2));
				bean.setStartDate(resultset.getDate(3));
				bean.setEndtDate(resultset.getDate(4));
				
			}
		}
		catch(Exception e)
		{
			throw new FeedBackException(e.getMessage());
		}
		
		return bean;
	}
	

}
