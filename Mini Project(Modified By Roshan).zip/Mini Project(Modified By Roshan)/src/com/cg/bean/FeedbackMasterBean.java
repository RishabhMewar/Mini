package com.cg.bean;

public class FeedbackMasterBean {
	
	private String trainingCode;
	private String participantCode;
	private int presentationCommunication;
	private int clearifyDoubts;
	private int timeManagement;
	private int handOuts;
	private int hwSwNtwrk;
	private String comments;
	private String suggestions;
	public FeedbackMasterBean() {
		super();
	}
	public FeedbackMasterBean(String trainingCode, String participantCode,
			int presentationCommunication, int clearifyDoubts,
			int timeManagement, int handOuts, int hwSwNtwrk, String comments,
			String suggestions) {
		super();
		this.trainingCode = trainingCode;
		this.participantCode = participantCode;
		this.presentationCommunication = presentationCommunication;
		this.clearifyDoubts = clearifyDoubts;
		this.timeManagement = timeManagement;
		this.handOuts = handOuts;
		this.hwSwNtwrk = hwSwNtwrk;
		this.comments = comments;
		this.suggestions = suggestions;
	}
	public String getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}
	public String getParticipantCode() {
		return participantCode;
	}
	public void setParticipantCode(String participantCode) {
		this.participantCode = participantCode;
	}
	public int getPresentationCommunication() {
		return presentationCommunication;
	}
	public void setPresentationCommunication(int presentationCommunication) {
		this.presentationCommunication = presentationCommunication;
	}
	public int getClearifyDoubts() {
		return clearifyDoubts;
	}
	public void setClearifyDoubts(int clearifyDoubts) {
		this.clearifyDoubts = clearifyDoubts;
	}
	public int getTimeManagement() {
		return timeManagement;
	}
	public void setTimeManagement(int timeManagement) {
		this.timeManagement = timeManagement;
	}
	public int getHandOuts() {
		return handOuts;
	}
	public void setHandOuts(int handOuts) {
		this.handOuts = handOuts;
	}
	public int getHwSwNtwrk() {
		return hwSwNtwrk;
	}
	public void setHwSwNtwrk(int hwSwNtwrk) {
		this.hwSwNtwrk = hwSwNtwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	@Override
	public String toString() {
		return "FeedbackMasterBean [trainingCode=" + trainingCode
				+ ", participantCode=" + participantCode
				+ ", presentationCommunication=" + presentationCommunication
				+ ", clearifyDoubts=" + clearifyDoubts + ", timeManagement="
				+ timeManagement + ", handOuts=" + handOuts + ", hwSwNtwrk="
				+ hwSwNtwrk + ", comments=" + comments + ", suggestions="
				+ suggestions + "]";
	}
	
	
	
}
