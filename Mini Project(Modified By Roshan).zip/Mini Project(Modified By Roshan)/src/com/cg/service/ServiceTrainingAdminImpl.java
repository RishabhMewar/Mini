package com.cg.service;

import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;

public class ServiceTrainingAdminImpl implements IServiceTrainingAdmin {

	@Override
	public boolean facultyMaintenance(FacultySkillBean faculty)
			throws FeedBackException {
		
		return false;
	}

	@Override
	public boolean courseMaintenance(CourseMasterBean course)
			throws FeedBackException {
		
		return false;
	}

	@Override
	public List<FacultySkillBean> viewFaculty() throws FeedBackException {
		
		return null;
	}

	@Override
	public boolean updateFaculty(FacultySkillBean faculty)
			throws FeedBackException {
		
		return false;
	}

	@Override
	public boolean deleteFaculty(String facultyCode) throws FeedBackException {
		
		return false;
	}

	@Override
	public List<FeedbackMasterBean> viewFacultyWiseReport(int month)
			throws FeedBackException {
		
		return null;
	}

	@Override
	public FacultySkillBean retrieveFaculty(String facultyCode) {
		
		return null;
	}

	@Override
	public String retrieveFacultyCode(String trainingCode) {
		
		return null;
	}
	
	

}
