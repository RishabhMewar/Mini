package com.cg.service;

import java.util.List;

import com.cg.bean.EmployeeMasterBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.bean.TrainingParticipantEnrollmentBean;
import com.cg.bean.TrainingProgramBean;
import com.cg.exception.FeedBackException;


public interface IServiceTrainingCoordinators {
	public boolean trainingProgramMaintenance(TrainingProgramBean trainingProgram) throws FeedBackException;
	public boolean participantEnrollment(TrainingParticipantEnrollmentBean participant) throws  FeedBackException;
	public boolean employeeParticipant(EmployeeMasterBean employee) throws  FeedBackException;
	public List<TrainingProgramBean> viewTrainingProgram() throws  FeedBackException;
	public boolean updateTraining(TrainingProgramBean trainingProgram) throws  FeedBackException;
	public boolean deleteTraining(String trainingCode) throws  FeedBackException;
	public List<FeedbackMasterBean> viewTrainingProgramReport(int month) throws  FeedBackException;
	public TrainingProgramBean retrieveTraining(String trainingCode) throws FeedBackException;

}
