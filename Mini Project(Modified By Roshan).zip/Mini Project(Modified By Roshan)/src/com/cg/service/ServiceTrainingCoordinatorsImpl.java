package com.cg.service;

import java.util.List;

import com.cg.bean.EmployeeMasterBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.bean.TrainingParticipantEnrollmentBean;
import com.cg.bean.TrainingProgramBean;
import com.cg.dao.ITrainingCoordinatorsDAO;
import com.cg.dao.TrainingCoordinatorsDAOImpl;
import com.cg.exception.FeedBackException;

public class ServiceTrainingCoordinatorsImpl implements IServiceTrainingCoordinators {
	
	ITrainingCoordinatorsDAO coordinatorDao = new TrainingCoordinatorsDAOImpl();

	@Override
	public boolean trainingProgramMaintenance(
			TrainingProgramBean trainingProgram) throws FeedBackException {
		
		return coordinatorDao.trainingProgramMaintenance(trainingProgram);
	}

	@Override
	public boolean participantEnrollment(
			TrainingParticipantEnrollmentBean participant)
			throws FeedBackException {
		
		return coordinatorDao.participantEnrollment(participant);
	}

	@Override
	public boolean employeeParticipant(EmployeeMasterBean employee)
			throws FeedBackException {
		
		return coordinatorDao.employeeParticipant(employee);
	}

	@Override
	public List<TrainingProgramBean> viewTrainingProgram()
			throws FeedBackException {
		
		return coordinatorDao.viewTrainingProgram();
	}

	@Override
	public boolean updateTraining(TrainingProgramBean trainingProgram)
			throws FeedBackException {
		
		return coordinatorDao.updateTraining(trainingProgram);
	}

	@Override
	public boolean deleteTraining(String trainingCode) throws FeedBackException {
		
		return coordinatorDao.deleteTraining(trainingCode);
	}

	@Override
	public List<FeedbackMasterBean> viewTrainingProgramReport(int month)
			throws FeedBackException {
		
		return coordinatorDao.viewTrainingProgramReport(month);
	}

	@Override
	public TrainingProgramBean retrieveTraining(String trainingCode) throws FeedBackException {
		
		return coordinatorDao.retrieveTraining(trainingCode);
	}
	
	

	


}
